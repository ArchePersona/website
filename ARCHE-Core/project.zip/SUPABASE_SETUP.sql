-- ============================================================
-- BRUNEL — Supabase Memory Schema
-- Run this ONCE in Supabase SQL Editor (Project → SQL Editor → New Query)
-- ============================================================

-- 1. Create the memories table
CREATE TABLE IF NOT EXISTS public.memories (
    id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id      uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    persona      text NOT NULL DEFAULT 'brunel',
    memory_text  text NOT NULL,
    category     text NOT NULL DEFAULT 'general',
    confirmed    boolean NOT NULL DEFAULT true,
    private      boolean NOT NULL DEFAULT true,
    created_at   timestamptz NOT NULL DEFAULT now()
);

-- 2. Index for the recall query (user + persona + recency)
CREATE INDEX IF NOT EXISTS idx_memories_user_persona_created
    ON public.memories (user_id, persona, created_at DESC)
    WHERE confirmed = true AND private = true;

-- 3. Enable Row Level Security
ALTER TABLE public.memories ENABLE ROW LEVEL SECURITY;

-- 4. Ownership-only policies (auth.uid() = user_id)
DROP POLICY IF EXISTS "owner_select" ON public.memories;
CREATE POLICY "owner_select"
    ON public.memories
    FOR SELECT
    TO authenticated
    USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "owner_insert" ON public.memories;
CREATE POLICY "owner_insert"
    ON public.memories
    FOR INSERT
    TO authenticated
    WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "owner_update" ON public.memories;
CREATE POLICY "owner_update"
    ON public.memories
    FOR UPDATE
    TO authenticated
    USING (auth.uid() = user_id)
    WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "owner_delete" ON public.memories;
CREATE POLICY "owner_delete"
    ON public.memories
    FOR DELETE
    TO authenticated
    USING (auth.uid() = user_id);

-- 5. Grants for the API roles
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.memories TO authenticated;

-- ============================================================
-- Done. Verify with:
--   SELECT * FROM public.memories LIMIT 1;   -- should return 0 rows, no error
-- ============================================================
