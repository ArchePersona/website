# Test Credentials

This file holds shared test/demo credentials used by automated testing agents and forks.

## Supabase (BRUNEL)

- **Project URL:** `https://eaczccnkbgbvtbtuvlbq.supabase.co`
- **Anon (publishable) key:** `sb_publishable_OZqq96SpvD6dOpuN5W_DeA_WFeyGbxS` (safe for frontend)
- **Service role key:** stored only as `SUPABASE_SERVICE_ROLE_KEY` env var on backend (never in this file)
- **Email confirmation:** OFF (per investor demo config — must be confirmed by owner in Supabase dashboard)

## Test user account
_No persistent shared test account yet. Testing agent should create a one-off account via the signup flow:_

- email: `e1-test-<timestamp>@example.com`
- password: `Brunel-Test-2026!`

## Anthropic Claude
Configured via `ANTHROPIC_API_KEY` in `/app/backend/.env` (do not paste here).
