# ArchePersona RK 2 — Demo PRD

**Owner:** Darren Hall  ·  **Working name:** ArchePersona  ·  **Tagline:** *Unforgettably. Yours.*

## Problem
Most LLMs reset every conversation. ArchePersona doesn't. The demo's job is to make that difference *physically visible* — same input, two engines, divergent outcomes, on a single screen.

## What was built (Jan 2026)
- **Backend (FastAPI + MongoDB + Anthropic SDK)**
  - Cognitive engine `rk_engine.py`: Sniffers → Translator A1 (token lookup) → Translator A2 (weight) → broadcast → six agents (Perception, Memory, Reason, Threat, Social, Reward) → Tribunal (Sentinel/Empath/Arbiter, consensus 0–3) → emergent 9-state Polyvagal grid → mode → behavioral directive → enriched system prompt
  - Architectural invariants honored: no agent suppressed, baseline-attractor with fast-escalate / slow-de-escalate, history immutable, sniffers always on
  - Endpoints: `POST /api/chat` (target = `rk_only` | `plain_only` | `both`, parallel via `asyncio.gather`), `POST /api/reset`, `GET /api/session/{id}`
  - Memory cap: last 50 turns; durable fact extraction (name, likes, dislikes, work)
  - Claude Sonnet 4.5 via user-supplied `ANTHROPIC_API_KEY`
- **Frontend (React + Tailwind)**
  - Dark teal terminal aesthetic (`#061d27`), JetBrains Mono + Cormorant Garamond, neon green + gold accents — matches the existing ArchePersona landing page
  - Two side-by-side panels: RK ENGINE (signal-aware) vs PLAIN LLM (stateless)
  - Headers: **"RK Remembers"** / **"Others forget"**
  - RK status strip: 6 vertical color-coded 0–9 weight meters + State badge + Mode badge + Flag chips
  - Per-panel inputs: **PRIME RK ONLY** (active) vs **NO PRIMING AVAILABLE** (disabled — the disabled state is itself a demonstration)
  - Master input: **BOTH SIDES RECEIVE THIS**
  - Reset Session button (top right)
  - localStorage session ID, MongoDB-backed persistence, auto-hydration on reload

## What's exposed in the UI (no IP leak)
State name (Warm/Curious/Focused/Guarded/Avoidant/Stuck/Retreating/Gentle/Shutdown), zone color, Mode name (NORMAL/RELATIONAL/EXPLORATORY/CLINICAL/PROTECTIVE), abstract flag chips, abstract 0–9 meters.

## What's hidden
Agent names · Tribunal overseer pairings · Calibrators (Ego/Novelty/Drift) · EPS packet · cache states · action containers · vote thresholds · veto-political-cost mechanics · Polyvagal vocabulary in labels.

## Test status (Jan 2026, iteration 1)
✅ Backend: 11/11 pytest pass
✅ Frontend: 15/15 Playwright assertions pass
✅ End-to-end: prime RK alone → ask both → RK recalls primed facts, Plain LLM does not

## Deferred (Phase 2+)
- Real feedback loop (weight learning from outcome correlation)
- Whisperers / Calibrators long-term trims
- Multi-modal sniffers (audio/biometric/video)
- Real CAN-bus broadcast layer
- Analytical lenses

## Files
- `/app/backend/server.py` · `/app/backend/rk_engine.py` · `/app/backend/supabase_helper.py` · `/app/backend/.env`
- `/app/frontend/src/App.js` · `/app/frontend/src/AuthContext.js` · `/app/frontend/src/Login.js` · `/app/frontend/src/ProtectedRoute.js` · `/app/frontend/src/Chat.js` · `/app/frontend/src/lib/supabase.js` · `/app/frontend/src/App.css`
- `/app/backend/tests/backend_test.py` (regression)
- `/app/SUPABASE_SETUP.sql` (one-shot DDL for `public.memories` + RLS)

## Auth + persistent memory (Feb 2026)
- **Auth provider:** Supabase (email/password). Google + Apple stubs present, disabled until configured.
- **Frontend client:** `@supabase/supabase-js` with publishable (anon) key only; session persisted via localStorage; `/disclaimer` and `/brunel` gated by `<ProtectedRoute>`.
- **Backend verification:** every `/api/chat`, `/api/reset`, `/api/session/{id}` requires `Authorization: Bearer <jwt>`; verified via `supabase.auth.get_user(token)` (anon-key client, no service-role required).
- **Session keying:** authenticated user's `auth.uid()` IS the session_id (no more browser-volatile session). Memories survive across devices.
- **Memory storage:** `public.memories` (Supabase Postgres) — ownership-only RLS (`auth.uid() = user_id`). Per-message contract:
    - Recall: last 10 rows for current user, persona='brunel', confirmed=true, private=true → injected into system prompt.
    - Write: heuristic regex extraction (name/likes/dislikes/possessions/work) → INSERT with persona='brunel', category auto-detected, confirmed=true, private=true.
- **Service role key:** optional, env-only placeholder; not used in user data path. Reserved for future admin tasks.
- **Token discipline preserved:** PROMPT_HISTORY_TURNS still 8; FACTS_IN_PROMPT still 6.

## Backlog / next
- Run `/app/SUPABASE_SETUP.sql` in Supabase SQL Editor (one-time owner action).
- Confirm Supabase Auth dashboard: Email provider enabled, "Confirm email" OFF for demo.
- Memory-count indicator in BRUNEL top bar ("BRUNEL knows X things about you") — still pending.
- Voice-to-text in chat input (Whisper via Emergent LLM key) — mic button, MediaRecorder capture, `POST /api/transcribe` route, handles natural pauses / "um"s / mid-thought drift unlike Web Speech API. Build est. ~20-25 credits, run cost ~$0.006/min.
- Drag-and-drop document ingestion (PDF / DOCX / TXT / MD) — persistent storage in Supabase Storage bucket (`brunel-documents`, owner-only RLS). Spec: **cap 10 MB / ~50 pages**; **summarize-on-upload** (extract text once, Claude condenses to ~1 paragraph, only the summary ever reaches BRUNEL's prompt — keeps him conversational, not a research assistant). Document title + summary saved into `public.memories` (category=`document`) so BRUNEL can recall "the pitch deck you sent me last week". Users see a doc library in their account. Build est. ~35-45 credits.
- Fix GitHub raw HTML links in `Landing.js` (mime renders as text — host locally or via gh-pages).
- Re-evaluate strict CORS lockdown for `/api/chat`.

## UI refinements + working memory + admin (Feb–May 2026)
- Topic-entropy working memory: per-turn token counter w/ decay (0.85), floor 0.20, top-3 surfacing above weight 1.4. Persisted on Mongo session as `topic_entropy`.
- Admin panel at `/admin` — gated by `ADMIN_EMAILS` env (currently `archepersona@gmail.com`). Force state + mode via dropdowns; PUT/DELETE `/api/admin/override`.
- System prompt hardened against reflexive servicing tails ("how can I help?", "what's next?", "let me know if…").
- Landing redesigned to Atari-retro aesthetic: ARCHEPERSONA wordmark (clamp 320–680px), IBM Plex Mono, page bg #010407 sampled from wordmark png to remove visible rectangle.
- "Introducing BRUNEL" block boxed with subtle green tint to match chat-input area; kicker re-typed to match gray body voice.
- Tagline "Unforgettably. Yours." lifted tight under wordmark (`margin-top: -18px` desktop / -10px mobile).
- Mobile chat topbar: email hidden < 640px, Sign-out / Admin buttons compress to icons-only, `.brand-sub` hidden, font scaled.
- "Admin" button visible in chat topbar ONLY when `user.email === archepersona@gmail.com`.
- Google + Apple OAuth buttons removed from Login (per Feb 2026 brief — email/password only).
- `archepersona.online` link removed from Landing top nav.
- Reset Session button removed from chat (only Sign out remains).

## Future: continuity-transfer (P2)
Goal: make BRUNEL continuity feel persistent and transferable rather than disposable.

Concept: anonymous/demo BRUNEL users (when re-introduced) get a one-time prompt at signup — *"Import previous BRUNEL continuity?"* — that migrates prior session memories + history onto their new authenticated `auth.uid()`, preserving persona separation.

Open design questions to resolve before building:
- Anonymous sessions don't currently exist in the auth-gated app — need to decide whether `/brunel` becomes optionally anonymous again, or whether the "import" flow accepts a transferable session token / one-time code.
- How to authenticate "this anonymous session was mine" without a logged-in identity (cookie? localStorage session_id + signature? short-lived claim code?).
- Migration target: Supabase `public.memories` (rewrite `user_id` from null/anon → new `auth.uid()`) and/or Mongo `sessions.session_id` (rename to user_id).
- Confirmation UX: show counts ("12 memories, 47 turns") before the user commits, with a "Decline" path that wipes the anonymous trail.

